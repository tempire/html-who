use Modern::Perl;
use Mojo::DOM;
use Data::Dumper;

#print Dumper +Mojo::DOM->new->parse('
#my $a = Mojo::DOM->new;
#print Dumper $a;
#$a->append_content('
  #<a href="http://mojocasts.com">
  #<img src="http://whatever.com" />
  #<img src="http://whenever.com" />
  #</a>
#');
#$a->at('a')->append('<h1>hee</h1>');
#print $a;
#exit;

Thing->new->html(
  [h1 => 'hello!'],
  [a => href => "http://mojocasts.com",
    [img => src => "http://farm5.static.flickr.com/4135/4815586283_fea2da5c2b.jpg"],
    [img => src => "http://farm5.static.flickr.com/4135/4815586283_fea2da5c2b.jpg"]],
  [ul =>
    [li => [a => href => "a.com", [img => src => "a.png"]]],
    [li => [a => href => "a.com", [img => src => "a.png"]]],
    [li => [a => href => "a.com", [img => src => "a.png"]]],
    [li => [a => href => "a.com", [img => src => "a.png"]]]],
  [div => class => 'header', 
    [div => style => 'display: none;' => ['text inside']],
    [div => class => 'subheader' => ['text inside 2']]]
);

#print Dumper Thing->new->html(
#  -h1 => 'hello!',
#  -a => href => "http://mojocasts.com", [
#    -img => src => "http://farm5.static.flickr.com/4135/4815586283_fea2da5c2b.jpg",
#    -img => src => "http://farm5.static.flickr.com/4135/4815586283_fea2da5c2b.jpg"],
#  -ul => [
#    -li => class => 'odd',  [-a => href => "a.com", [-img => src => "a.png"]],
#    -li => class => 'even', [-a => href => "a.com", [-img => src => "a.png"]],
#    -li => [-a => href => "a.com", [-img => src => "a.png"]],
#    -li => [-a => href => "a.com", [-img => src => "a.png", alt => "A image"]]],
#  -div => class => 'header', [
#    -div => style => 'display: none;' => 'text inside',
#    -div => class => 'subheader' => 'text inside'
#  ],
#);

use Test::Most;

my $t = Thing->new;
ok $t->has_children(a => []);
ok $t->has_children(a => href => 'http://' => 'alt' => ['link']);
ok $t->has_no_children(a => href => 'http://');
ok $t->has_no_children(a => href => 'http://' => 'alt');
is $t->examine(a => href => 'http://' => 'alt') => '<a href="http://" alt />';
is $t->open_tag(a => href => 'http://', rel => 'next', 'alt') => '<a href="http://" rel="next" alt>';
is $t->open_tag(a => href => 'http://', rel => 'next') => '<a href="http://" rel="next">';
is $t->open_tag(a => href => 'http://', rel => 'next', border => 0) => '<a href="http://" rel="next" border="0">';
is $t->open_tag(a => href => 'http://', border => 0) => '<a href="http://" border="0">';
is $t->close_tag(a => href => 'http://' => 'alt') => '</a>';
is $t->enclosed_tag(a => href => 'http://' => 'alt') => '<a href="http://" alt />';
is $t->enclosed_tag(a => href => 'http://' => border => 0) => '<a href="http://" border="0" />';
is $t->text_node('text') => 'text';
is $t->examine(a => href => 'http://' => 'alt' => ['link']) => '<a href="http://" alt>link</a>';
is $t->examine(
  a => href => 'http://', rel => 'next' => [ img => src => 'http://', border => 0 ]
) => '<a href="http://" rel="next"><img src="http://" border="0" /></a>';

is $t->html(
    [a => href => 'http://' => 'alt' => [ img => src => 'http://', border => 0 ]],
    [a => href => 'http://' => 'alt' => [ img => src => 'http://', border => 0 ]]
) => '<a href="http://" alt><img src="http://" border="0" /></a><a href="http://" alt><img src="http://" border="0" /></a>';

done_testing;

package Thing;
use Mojo::Base -base;
use Data::Dumper;
use Mojo::DOM;
use Devel::Dwarn;

sub html {
  my $self = shift;

  return join '', map $self->examine(@$_) => @_;
}

# for one element
sub examine {
  my $self = shift;

  # Tag - base case
  return $self->enclosed_tag(@_) if $self->has_no_children(@_);

  # Child arrayref, descend recursively into child
  my @children = @{+pop};
  return $self->open_tag(@_) . $self->examine(@children) . $self->close_tag(@_);
}

sub text_node {
  return pop;
}

sub open_tag {
  my $self = shift;

  # tag name
  my $tag = '<' . shift;

  # attributes
  my $count = @_;
  for (my $i=0; $i<$count, @_, @_>1; $i=$i+2) {
    $tag .= sprintf(' %s="%s"', shift, shift);
  }

  # unpaired keys (<input type="checkbox" checked />)
  $tag .= ' ' . shift if @_;

  $tag .= '>';

  return $tag;
}

sub close_tag {
  my $self = shift;

  return '</' . shift . '>';
}

sub enclosed_tag {
  my $self = shift;

  # text node
  return $self->text_node(shift) if @_ == 1;

  my $tag = $self->open_tag(@_);
  $tag = substr $tag, 0, -1;
  $tag .= ' />';

  return $tag;
}

sub has_children {
  return 1 if ref pop eq 'ARRAY';
}

sub has_no_children {
  return !shift->has_children(pop);
}

1;
